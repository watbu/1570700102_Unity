﻿using UnityEngine;
using System.Collections;

public class MoveTrap : MonoBehaviour {
	public float moveSpeed;
	public GameObject SS;
	public Vector3 GetTrap;
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
		transform.Translate(Vector3.up * moveSpeed * Time.deltaTime);
	}

	void OnCollisionStay(Collision other)
	{

		if (other.collider.tag == "Wall") 
		{

			transform.position = new Vector3(5.94, 2.374, 0);
		}

		 }
	}
